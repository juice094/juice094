# 周景潇

阿里巴巴达摩院 · AI Agent 基础设施 / 大模型系统工程

---

## 教育背景

**甘肃农业大学** · 数据科学与大数据技术 · 工学学士 · 2023.09 — 2027.06
信息科学技术学院 · 均分 83 / 核心课 86 · 专业前 10%

主修课程：数据结构与算法、操作系统、计算机网络、数据库原理、分布式系统、机器学习

## 个人简介

独立用 Rust 从零构建 AI Agent 运行时、P2P 文件同步协议栈与开发者工作空间编译器。
专注于本地优先架构、零外部依赖部署与生产级 Rust 工程实践。

## 技术能力

我主要用 *Rust* 写系统级软件，也常用 *Python* 做数据分析、测试脚本和实验验证。

- *异步与网络*：Tokio、Axum、Tower、reqwest、WebSocket、rustls
- *存储与检索*：SQLite、rusqlite、Tantivy、BM25、embedding 向量搜索
- *AI Agent*：ReAct / Plan 双模式、MCP 协议、Multi-Agent 编排、RAG 检索增强
- *分布式与 P2P*：BEP 协议、STUN、UPnP、Relay、NAT 穿透
- *跨平台 UI*：egui、ratatui、UniFFI
- *安全*：ChaCha20-Poly1305、TLS 1.3、自签名设备证书
- *工程化*：Cargo Workspace、GitHub Actions、Clippy、tracing、criterion

## 项目经历

### Clarity — 让 AI 助手跨设备保持一致人格的本地 Agent 系统
https://github.com/juice094/clarity · 2026.04 — 至今

23 workspace crate · 152K LOC · 1,243 tests · 零 panic

- 本地优先的 AI Agent 运行时：ReAct + Plan 双模式执行，步骤遗漏率从约 40% 降到接近零。
- MCP 工具协议三传输实现（stdio / SSE / WebSocket），LLM 可调本地文件、搜索、shell 等能力。
- SQLite 单文件混合记忆检索：手写向量相似度 UDF + BM25 关键词检索，零外部向量数据库依赖。
- 桌面 GUI（egui）、终端 UI（ratatui）、后台服务、移动端 FFI（UniFFI）共享同一 Agent 内核。

### devbase — 把代码和笔记编译成 AI 能理解的上下文
https://github.com/juice094/devbase · 2026.01 — 至今

12 workspace crate + 主 crate · 56K LOC · 71 MCP 工具

- 通过 MCP 协议暴露 71 个 stdio 工具，覆盖代码符号检索、Git 分析、笔记搜索、YAML 工作流执行。
- 零云端依赖语义检索：Tantivy 全文/符号索引 + SQLite BLOB 存 embedding + 手写 cosine_similarity UDF。
- YAML DAG 工作流引擎：支持 Skill、子工作流、并行、条件判断、循环 5 种步骤类型。

### syncthing-rust — 无需云盘的 P2P 文件同步工具
https://github.com/juice094/syncthing-rust · 2025.11 — 至今

8 library crate + 5 命令二进制 · 59K LOC · ~12 MB 单二进制

- 块级文件同步 + Windows 句柄冲突退避 + 三路文本合并 + Simple/Staggered 版本归档。
- 从零实现 Syncthing BEP 协议，protobuf 编解码，wire_compat 集成测试验证与 Go 版线路兼容。
- 多路径 NAT 穿透：UDP 本地广播、全球发现、STUN、UPnP、Relay 中继回退。

## 研究经历

**检索增强生成中输出结构的实证研究** · 2026.03 — 至今 · https://github.com/juice094/acr-select

围绕 RAG 系统中“输出格式如何影响内容质量”设计受控实验：40 个实验条件、3000+ 样本、跨 4 种模型架构验证。论文撰写中。

## 奖项与认证

- AI 应用工程师（中级）— 工业和信息化部认证
- 日语专业四级（CJT-4）· 大学英语四级（CET-4）

## 其他

- 到岗时间：2026.07；可实习 3–6 个月，每周 5 天
- 公网可访问：Clarity Web 前端（Vercel）、syncthing-rust P2P 节点（日本 VPS）
